// micrositeTemp controller
app.controller('micrositeController', function($scope, $rootScope, $location, $anchorScroll,$http) {
    $scope.hideInit = false;
    $scope.templateURL;
    $scope.myvar = false;
    $scope.editShow = false;
    $scope.popup_window=false;
    $scope.plus_button=true;
    $scope.IsVisibleImage = false;
    $scope.titleName = localStorage.getItem('title') ? localStorage.getItem('title') : "Company Name and Logo";
    
    if($scope.contenEditable=="true"){
      $scope.myvar = true;
    }
    $scope.MessageType = "theme";
    $scope.defaultImg = "assets/images/"+$scope.MessageType+".png";

    $http.get("json/background_image.json")
    .then(function(response) {
        $scope.bgImages = response.data;
    }, function(response) {
        $scope.bgImages = "Something went wrong";
    });


    if (localStorage.getItem('hostClick') != undefined)
        $rootScope.hostClicked = localStorage.getItem('hostClick');

    $scope.chooseTemplate = function(ev) {
        $scope.hideInit = true;
        $scope.templateURL = 'template/aboutTemp1.html'
        console.log(ev)
    }
    $scope.backgroundImage = function(){
        $scope.IsVisibleImage = $scope.IsVisibleImage ? false : true;
        $scope.popup_window=false;

    }
    $scope.changeImage = function(sel, index) {
        console.log(sel)
        console.log($scope.bgImages[sel].image);
        currTheme=sel;
        $scope.selected=index;        
        $scope.bgImages[currTheme].imageSelected =false;
        $scope.bgImages[sel].imageSelected =true;
        $scope.MessageType = $scope.MessageType == $scope.bgImages[sel].image ? 'theme' : $scope.bgImages[sel].image;
        console.log($scope.MessageType);
        $scope.defaultImg = "assets/images/"+$scope.MessageType+".png";
    }

    //choose file
    // $scope.$watch('file', function(newfile, oldfile) {
    //   if(angular.equals(newfile, oldfile) ){
    //     return;
    //   }

    //   uploadService.upload(newfile).then(function(res){
    //     // DO SOMETHING WITH THE RESULT!
    //     console.log("result", res);
    //   })
    // });
  

    // Menu functionality
    $scope.menulist = ['HOME', 'FIND TALENT', 'FIND A JOB'];
    $scope.names = ['FAQ', 'HELP'];
    var flag = 0;
    $scope.save = function(temp) {
        console.log(temp);
        
        $scope.menulist.push(temp);

        $scope.names.forEach(function(x, index) {
            if (temp === x) {
                $scope.names.splice(index, 1);
            }
        })
        if (temp == 'HELP') {
            $scope.output1 = 'HELP';
            flag++;
            console.log(flag);
            if(flag == 2){
              $scope.plus_button = false;
            }

        } else if (temp == 'FAQ') {
            $scope.output2 = 'FAQ';
            flag++;
            console.log(flag);
            if(flag == 2){
              $scope.plus_button = false;
            }
        }
        $scope.myvar = false;
    }
    $scope.plus = function() {
        $scope.myvar = true;
        $scope.IsVisible =false;

    }
    $scope.disableEditor = function() {
        $scope.myvar = false;
    }
    $scope.scrollTo = function(scrollLocation) {
        var old = $location.hash();
        $location.hash(scrollLocation);
        $anchorScroll();
        $location.hash(old);
    }
    


// Font edit functionality
     $scope.text_editor_popup=function() {
        $scope.popup_window= !$scope.popup_window;
        console.log("changed");
        $scope.IsVisibleImage =false;
      }
       $scope.fonts = [
            "Arial",
            "Tahoma",
            "Helvetica",
            "Verdana",
            "Sans-serif",
            "Impact",
            "Courier New",
            "Georgia",
            "Arial Black",
            "Times New Roman",
            "Bold",
            "Italic"
        ];
      $scope.class="" ;
      $scope.text = {
            font: "Arial",
            size: 60
        };
        $scope.boldText=function(){
       $('.bannerTextTitle').toggleClass("bold");
       
    }
    $scope.italicText=function(){
        $('.bannerTextTitle').toggleClass("italic");
       
    }
     $scope.underlineText=function(){
        $('.bannerTextTitle').toggleClass("underline");
    }
     $scope.btnjustify=function(){
      console.log("justify");
      $scope.class="text_type_justify";
       
    }
     $scope.btnright=function(){
      console.log("right");
      $scope.class="text_type_right";
       
    }
     $scope.btncenter=function(){
      console.log("center");
      $scope.class="text_type_center";
       
    }
     $scope.btnleft=function(){
      console.log("left");
      $scope.class="text_type_left";
       
    } 
    /*----geolocation maps---------*/
    var map;
var global_markers = [];    
var markers = [[37.09024, -95.712891, 'trialhead0']];

var infowindow = new google.maps.InfoWindow({});

function initialize() {
    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(40.77627, -73.910965);
    var myOptions = {
        zoom: 1,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    addMarker();
} 
function addMarker() {
    for (var i = 0; i < markers.length; i++) {
        // obtain the attribues of each marker
        var lat = parseFloat(markers[i][0]);
        var lng = parseFloat(markers[i][1]);
        var trailhead_name = markers[i][2];

        var myLatlng = new google.maps.LatLng(lat, lng);

        var contentString = "<html><body><div><p><h2>" + trailhead_name + "</h2></p></div></body></html>";

        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title: "Coordinates: " + lat + " , " + lng + " | Trailhead name: " + trailhead_name
        });

        marker['infowindow'] = contentString;

        global_markers[i] = marker;

        google.maps.event.addListener(global_markers[i], 'click', function() {
            infowindow.setContent(this['infowindow']);
            infowindow.open(map, this);
        });
    }
}

window.onload = initialize; 
})
.controller("upload", ['$scope', '$http', 'uploadService', function($scope, $http, uploadService) {
    $scope.$watch('file', function(newfile, oldfile) {
      if(angular.equals(newfile, oldfile) ){
        return;
      }

      uploadService.upload(newfile).then(function(res){
        // DO SOMETHING WITH THE RESULT!
        console.log("result", res);
      })
    });

  }])
  .service("uploadService", function($http, $q) {

    return ({
      upload: upload
    });

    function upload(file) {
      var upl = $http({
        method: 'POST',
        url: '', // /api/upload
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        data: {
          upload: file
        },
        transformRequest: function(data, headersGetter) {
          var formData = new FormData();
          angular.forEach(data, function(value, key) {
            formData.append(key, value);
          });

          var headers = headersGetter();
          delete headers['Content-Type'];

          return formData;
        }
      });
      return upl.then(handleSuccess, handleError);

    } // End upload function

    // ---
    // PRIVATE METHODS.
    // ---
  
    function handleError(response, data) {
      if (!angular.isObject(response.data) ||!response.data.message) {
        return ($q.reject("An unknown error occurred."));
      }

      return ($q.reject(response.data.message));
    }

    function handleSuccess(response) {
      return (response);
    }

  })
  .directive("fileinput", [function() {
    return {
      scope: {
        fileinput: "=",
        filepreview: "="
      },
      link: function(scope, element, attributes) {
        element.bind("change", function(changeEvent) {
          scope.fileinput = changeEvent.target.files[0];
          var reader = new FileReader();
          reader.onload = function(loadEvent) {
            scope.$apply(function() {
              scope.filepreview = loadEvent.target.result;
            });
          }
          reader.readAsDataURL(scope.fileinput);
        });
      }
    }
  }]);