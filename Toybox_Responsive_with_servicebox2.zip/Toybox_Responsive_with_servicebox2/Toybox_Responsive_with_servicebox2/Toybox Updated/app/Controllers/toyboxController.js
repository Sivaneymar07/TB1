app.controller('toyboxController', function($scope, $location, $rootScope, $anchorScroll, $localStorage,$http) {
   
    $scope.MessageType = "#fdd500";
    // $scope.MessageType = "pink";
    $scope.defaultColor = $scope.MessageType;
         $scope.IsVisible = false;
    var currTheme= 0;
    $scope.selected=-1;

  
  $http.get("json/theme.json")
    .then(function(response) {
        $scope.themes = response.data;
    }, function(response) {
        $scope.themes = "Something went wrong";
    });
    $scope.store = function() {
        console.log($scope.titleName);
        localStorage.setItem('title', $scope.titleName);
        
        console.log($scope.titleName);
    }

    $scope.ShowHide = function() {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
    $scope.changeTheme = function(sel, index) {
        console.log(sel)
        console.log($scope.themes[sel].theme);
        currTheme=sel;
        $scope.selected=index;        
        $scope.themes[currTheme].themeSelected =false;
        $scope.themes[sel].themeSelected =true;
        $scope.MessageType = $scope.MessageType == $scope.themes[sel].theme ? 'theme' : $scope.themes[sel].theme;
        console.log($scope.MessageType);
    }   
    $scope.applyTheme = function() {
        console.log($scope.MessageType);
        $scope.defaultColor = $scope.MessageType;
        console.log($scope.defaultColor);
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
    $scope.cancelTheme = function() {
    	$scope.defaultImg = "assets/images/theme.png";
    	$scope.IsVisible = $scope.IsVisible ? false : true;
	}
});